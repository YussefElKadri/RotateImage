﻿using Girar_Imagem;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Girar_Imagem
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//CHAMAR("NomeCompletoApp" ; "NomeCompletoPastaSemEspaco\*.*")

			DateTime dataatual = DateTime.Now;
			DateTime datavencimento = new DateTime(year: 2050, 12, 31, 23, 59, 00);
			int comparativodata = DateTime.Compare(dataatual, datavencimento);
			LeituraArquivos novaleitura = new LeituraArquivos();

			if (comparativodata <= 0)
			{
				if (args.Length > 0)
				{
					for (int i = 0; i < args.Length; i++)
					{
						string somentepasta = Path.GetDirectoryName(args[i]);
						novaleitura.LeituraArquivosGiro(somentepasta);
					}
				}
				else if (args.Length <= 0)
				{
					string pasta = Directory.GetCurrentDirectory();
					novaleitura.LeituraArquivosGiro(pasta);
				}
			}
			else
			{
				MessageBox.Show("Sem licença!\nEntrar em contato com o Desenvolvedor - TopSolid\n(43) 9 9919-2981", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}
}
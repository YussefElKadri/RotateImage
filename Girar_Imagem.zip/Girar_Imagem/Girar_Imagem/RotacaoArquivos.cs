﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;

namespace Girar_Imagem
{
	internal class RotacaoArquivos
	{
		public string Rotacao(string novaimagem, int angulo)
		{
			Image arquivo = Image.FromFile(novaimagem);
			string pastaimagem = Path.GetDirectoryName(novaimagem);
			string nomeimagem = Path.GetFileNameWithoutExtension(novaimagem);
			int posicao = nomeimagem.ToString().IndexOf('-') + 1;
			string ext = ".png";
			string somentenomeimagem = pastaimagem + @"\" + nomeimagem.Substring(posicao) + ext;

			if (angulo == 0)
			{
				arquivo.RotateFlip(RotateFlipType.RotateNoneFlipNone);
				arquivo.Save(somentenomeimagem, ImageFormat.Png);
				arquivo.Dispose();
				File.Delete(novaimagem.ToString());
			}
			else if (angulo == 90)
			{
				arquivo.RotateFlip(RotateFlipType.Rotate270FlipNone);
				arquivo.Save(somentenomeimagem, ImageFormat.Png);
				arquivo.Dispose();
				File.Delete(novaimagem.ToString());
			}
			else if (angulo == 180)
			{
				arquivo.RotateFlip(RotateFlipType.Rotate180FlipNone);
				arquivo.Save(somentenomeimagem, ImageFormat.Png);
				arquivo.Dispose();
				File.Delete(novaimagem.ToString());

			}else if (angulo == 270)
			{
				arquivo.RotateFlip(RotateFlipType.Rotate90FlipNone);
				arquivo.Save(somentenomeimagem, ImageFormat.Png);
				arquivo.Dispose();
				File.Delete(novaimagem.ToString());
			}
			else
			{
				return null;
			}
			
			return novaimagem;
		}
	}
}

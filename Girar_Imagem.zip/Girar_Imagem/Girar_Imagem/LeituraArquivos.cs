﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Girar_Imagem;

namespace Girar_Imagem
{
	internal class LeituraArquivos
	{
		readonly List<string> Arquivos = new List<string>();
		public int Angulo { get; set; }
		public string Nomeimagem { get; set; }
		public string LeituraArquivosGiro(string pasta)
		{
			RotacaoArquivos novarotacao = new RotacaoArquivos();

			string[] arquivoslidospasta = Directory.GetFiles(pasta, "*.png");

			for (int i = 0; i < arquivoslidospasta.Length; i++)
			{
				if (arquivoslidospasta[i].ToString().Contains("-"))
				{
					Arquivos.Add(arquivoslidospasta[i]);
				}
			}

			for (int j = 0; j < Arquivos.Count; j++)
			{
				Nomeimagem = Arquivos[j];
				string somentenomeimagem = Path.GetFileNameWithoutExtension(Nomeimagem);
				int posicao = somentenomeimagem.ToString().IndexOf('-');
				Angulo = Convert.ToInt32(somentenomeimagem.Substring(0, posicao));
				novarotacao.Rotacao(Nomeimagem, Angulo);
			}

			return pasta;
		}
	}
}
